import re
import requests
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def index():
    url = request.args.get('url')
    if not url:
        return render_template('index.html')

    # 🔥 Vulnerability: Hanya memblokir string "localhost", bukan IP internal
    if 'localhost' in url:
        return "Blocked: 'localhost' not allowed", 403

    try:
        # Simulasi metadata AWS (kita mock saja)
        if '169.254.169.254' in url:
            if '/iam/security-credentials/' in url:
                # Simulasi respons metadata AWS yang berisi flag
                return '''
{
  "CloudTools-Role": {
    "AccessKeyId": "ASIA...",
    "SecretAccessKey": "SECRET...",
    "Token": "...",
    "Expiration": "2030-01-01T00:00:00Z",
    "flag": "CTF{5srF_4nd_th3_1nt3rn4l_c10ud}"
  }
}
                ''', 200, {'Content-Type': 'application/json'}
            else:
                return 'CloudTools-Role', 200
        else:
            # Untuk demo, kita tidak benar-benar fetch URL luar
            return f"Mock fetch to: {url}\n(Note: only 169.254.169.254 is functional)", 200

    except Exception as e:
        return f"Error: {str(e)}", 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)
