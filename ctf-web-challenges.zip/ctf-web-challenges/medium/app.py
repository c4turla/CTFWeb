from flask import Flask, render_template, request, session, redirect, url_for, jsonify

app = Flask(__name__)
app.secret_key = 'very_secret_key_please_change_in_prod_but_not_here'

# Simulasi database user
USERS = {
    1001: {"name": "Alice", "role": "user"},
    1: {"name": "Admin", "role": "admin", "admin_flag": "CTF{pr1v4t3_pr0f1l3_4cc3ss_gr4nt3d}"}
}

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        if username == 'alice':
            session['user_id'] = 1001
            return redirect(url_for('profile', id=1001))
        else:
            return "Invalid user", 403
    return render_template('login.html')

@app.route('/profile')
def profile():
    user_id = session.get('user_id')
    if not user_id:
        return redirect('/login')
    
    requested_id = request.args.get('id', type=int)
    if not requested_id:
        return "Missing id param", 400

    # 🔥 Vulnerability: Tidak memeriksa apakah requested_id milik user yang login
    user = USERS.get(requested_id)
    if not user:
        return "User not found", 404

    return render_template('profile.html', user=user, current_id=user_id)

@app.route('/')
def index():
    return redirect('/login')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
