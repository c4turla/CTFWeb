<?php
// Admin forget: old debug parameter still active
if (isset($_GET['debug']) && $_GET['debug'] === "1") {
    echo "<h3>DEBUG MODE ENABLED</h3>";
    echo "<pre>" . file_get_contents("flag.txt") . "</pre>";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Maintenance Mode</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="box">
        <h2>Website Under Maintenance</h2>
        <p>Please come back later.</p>
        <!-- TODO: Remove debug before launch -->
        <!-- developer-note: ?debug=1 -->
    </div>
</body>
</html>
